ddd --debugger '/Users/kujawa/Projects/CatHouseStudio/sparkcore/compilers/bin/arm-none-eabi-gdb _build/ble_app_template_s110_xxaa.out -ex "target extended-remote localhost:2331"'
