#!/bin/bash

/Applications/SEGGER/JLink/JLinkExe $*
true
#cd /opt/JLink_Linux_V462a
#./StartJLinkExe.sh $*
