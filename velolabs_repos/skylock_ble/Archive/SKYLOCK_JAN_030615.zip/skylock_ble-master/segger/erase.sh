/Applications/SEGGER/JLink/JLinkExe  erase.seg
