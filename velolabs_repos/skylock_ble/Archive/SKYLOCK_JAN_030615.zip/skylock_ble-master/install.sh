cd segger && sh install.sh 
