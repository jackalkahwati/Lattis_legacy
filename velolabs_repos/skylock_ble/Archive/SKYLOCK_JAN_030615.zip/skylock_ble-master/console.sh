#!/bin/sh
screen /dev/tty.usbmodem241141 115200
