#!/bin/sh
/Applications/SEGGER/JLink/JLinkGDBServer  -device nrf51822 -if SWD -speed 1000
